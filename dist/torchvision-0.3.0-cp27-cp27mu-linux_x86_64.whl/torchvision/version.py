__version__ = '0.3.0'
git_version = 'Unknown'
from torchvision import _C
if hasattr(_C, 'CUDA_VERSION'):
    cuda = _C.CUDA_VERSION
